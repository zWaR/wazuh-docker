"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Wazuh app - React component for show search and filter
 * Copyright (C) 2015-2020 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
const react_1 = __importStar(require("react"));
const eui_suggest_1 = require("../eui-suggest");
const wz_search_format_selector_1 = require("./wz-search-format-selector");
const wz_search_badges_1 = require("./wz-search-badges");
const eui_1 = require("@elastic/eui");
const q_handler_1 = require("./lib/q-handler");
const api_handler_1 = require("./lib/api-handler");
const wz_search_buttons_1 = require("./wz-search-buttons");
class WzSearchBar extends react_1.Component {
    constructor(props) {
        super(props);
        //#region Event methods
        this.onInputChange = (value) => {
            const { filters: currentFilters } = this.state;
            if (!this.state.searchFormat) {
                this.setState({
                    inputValue: value,
                    isProcessing: true,
                    isPopoverOpen: true
                });
                return;
            }
            const { isInvalid, filters } = this.suggestHandler.onInputChange(value, currentFilters);
            if (!isInvalid) {
                this.updateFilters(filters);
            }
            this.setState({
                inputValue: value,
                isProcessing: true,
                status: 'loading',
                isInvalid,
                isPopoverOpen: true,
                filters
            });
        };
        this.onKeyPress = (e) => {
            const { isInvalid, searchFormat } = this.state;
            if (e.key !== 'Enter' || isInvalid) {
                return;
            }
            const { inputValue, filters: currentFilters } = this.state;
            const { searchDisable } = this.props;
            let filters = {};
            let newInputValue = '';
            if ((this.suggestHandler.isSearch && !searchDisable) || !searchFormat) {
                filters = {
                    ...currentFilters,
                    ['search']: inputValue,
                };
            }
            else if (inputValue.length > 0) {
                const { inputValue: newInput, filters: newFilters } = this.suggestHandler.onKeyPress(inputValue, currentFilters);
                filters = { ...newFilters };
                newInputValue = newInput;
            }
            this.props.onInputChange(filters);
            this.setState({
                isProcessing: true,
                inputValue: newInputValue,
                filters,
                isPopoverOpen: false
            });
        };
        this.closePopover = () => {
            this.setState({ isPopoverOpen: false });
        };
        const searchFormat = this.selectSearchFormat(props);
        this.state = {
            searchFormat,
            suggestions: [],
            isProcessing: true,
            inputValue: '',
            isInvalid: false,
            status: 'unchanged',
            filters: props.initFilters || {},
            isPopoverOpen: false,
        };
    }
    selectSearchFormat(props) {
        const searchFormat = (props.defaultFormat)
            ? props.defaultFormat
            : (!!props.qSuggests)
                ? '?Q'
                : (props.apiSuggests)
                    ? 'API'
                    : '';
        return searchFormat;
    }
    selectSuggestHandler(searchFormat) {
        const { noDeleteFiltersOnUpdateSuggests } = this.props;
        const { filters } = this.state;
        if (searchFormat === '?Q') {
            this.suggestHandler = new q_handler_1.QHandler(this.props.qSuggests);
        }
        else {
            this.suggestHandler = new api_handler_1.ApiHandler(this.props.apiSuggests);
        }
        this.setState({
            isProcessing: true,
            suggestions: [],
            filters: noDeleteFiltersOnUpdateSuggests
                ? filters
                : {}
        });
    }
    async componentDidMount() {
        this.selectSuggestHandler(this.state.searchFormat);
        if (this.state.searchFormat) {
            const suggestsItems = [...await this.suggestHandler.buildSuggestItems('')];
            this.setState({ suggestions: suggestsItems });
        }
    }
    updateSuggestOnProps(qSuggestsPrev, apiSuggestsPrev) {
        const { qSuggests, apiSuggests } = this.props;
        const qSuggestsChanged = JSON.stringify(qSuggests) !== JSON.stringify(qSuggestsPrev);
        const apiSuggestsChanged = JSON.stringify(apiSuggests) !== JSON.stringify(apiSuggestsPrev);
        if (qSuggestsChanged || apiSuggestsChanged) {
            return true;
        }
        return false;
    }
    shouldComponentUpdate(nextProps, nextState) {
        if (nextState.isProcessing) {
            return true;
        }
        if (nextState.isPopoverOpen !== this.state.isPopoverOpen) {
            return true;
        }
        if (nextState.status !== this.state.status) {
            return true;
        }
        if (this.updateSuggestOnProps(nextProps.qSuggests, nextProps.apiSuggests)) {
            return true;
        }
        return true; // if false, it dont't update search field in Search bar in CDB lists section, maybe it would have to remove the function because always returns true (ReactComponent.shouldComponentUpdate returns true by default too)
    }
    async componentDidUpdate(prevProps) {
        if (this.updateSuggestOnProps(prevProps.qSuggests, prevProps.apiSuggests)) {
            this.selectSuggestHandler(this.state.searchFormat);
        }
        const { isProcessing } = this.state;
        if (!isProcessing) {
            return;
        }
        const { inputValue, isInvalid, searchFormat } = this.state;
        const { searchDisable } = this.props;
        if (isInvalid) {
            this.buildSuggestInvalid();
        }
        else {
            const suggestsItems = !!searchFormat ?
                [...await this.suggestHandler.buildSuggestItems(inputValue)]
                : [];
            const isSearchEnabled = (this.suggestHandler.inputStage === 'fields'
                && !searchDisable
                && inputValue !== '')
                || !searchFormat;
            if (isSearchEnabled) {
                const suggestSearch = this.buildSuggestFieldsSearch();
                suggestSearch && suggestsItems.unshift(suggestSearch);
            }
            await this.setState({
                status: 'unchanged',
                suggestions: suggestsItems,
                isProcessing: false,
            });
        }
    }
    buildSuggestInvalid() {
        const suggestsItems = [{
                type: { iconType: 'alert', color: 'tint2' },
                label: "Error",
                description: "The field are invalid"
            }];
        this.setState({
            isProcessing: false,
            suggestions: suggestsItems,
            status: 'unsaved',
        });
    }
    buildSuggestFieldsSearch() {
        const { inputValue, searchFormat } = this.state;
        if (this.suggestHandler.isSearch || !searchFormat) {
            const searchSuggestItem = {
                type: { iconType: 'search', color: 'tint8' },
                label: inputValue,
                description: 'Search'
            };
            return searchSuggestItem;
        }
    }
    makeSearch(item) {
        const { inputValue, filters: currentFilters } = this.state;
        const filters = { ...currentFilters };
        filters['search'] = inputValue;
        this.updateFilters(filters);
        this.setState({
            inputValue: '',
            suggestions: [],
            isProcessing: true,
            filters,
        });
    }
    makeFilter(item) {
        const { inputValue, filters } = this.state;
        const { inputValue: newInputValue, filters: newFilters } = this.suggestHandler.onItemClick(item, inputValue, filters);
        this.updateFilters(newFilters);
        this.setState({
            inputValue: newInputValue,
            suggestions: [],
            status: 'loading',
            filters: newFilters,
            isProcessing: true,
        });
    }
    updateFilters(newFilters) {
        const { filters } = this.state;
        if (JSON.stringify(filters) !== JSON.stringify(newFilters)) {
            this.props.onInputChange(newFilters);
            this.setState({ isPopoverOpen: false });
        }
    }
    onChangeSearchFormat(format) {
        this.setState({ searchFormat: format });
        this.selectSuggestHandler(format);
    }
    onItemClick(item) {
        if (item.type.iconType === 'search') {
            this.makeSearch(item);
        }
        else {
            this.makeFilter(item);
        }
    }
    onDeleteBadge(badge) {
        const { filters } = this.state;
        delete filters[badge.field];
        this.props.onInputChange(filters);
        this.setState({ filters, isProcessing: true });
    }
    onPopoverFocus(event) {
        this.setState({ isPopoverOpen: true });
    }
    async onButtonPress(filter) {
        await this.setState(state => ({
            isProcessing: true,
            filters: {
                ...state['filters'],
                ...filter
            },
        }));
        this.props.onInputChange(this.state.filters);
    }
    //#endregion
    //#region Renderer methods
    renderFormatSelector() {
        const { qSuggests, apiSuggests } = this.props;
        const { searchFormat } = this.state;
        const qFilterEnabled = !!qSuggests;
        const apiFilterEnabled = !!apiSuggests;
        if (!qFilterEnabled && !apiFilterEnabled) {
            return null;
        }
        return (react_1.default.createElement(wz_search_format_selector_1.WzSearchFormatSelector, { onChange: this.onChangeSearchFormat.bind(this), format: searchFormat, qFilterEnabled: qFilterEnabled, apiFilterEnabled: apiFilterEnabled }));
    }
    render() {
        const { status, suggestions, inputValue, isInvalid, filters, isPopoverOpen } = this.state;
        const { placeholder, buttonOptions } = this.props;
        const formatedFilter = [...Object.keys(filters).map((item) => { return { field: item, value: filters[item] }; })];
        const searchFormatSelector = this.renderFormatSelector();
        return (react_1.default.createElement("div", null,
            react_1.default.createElement(eui_1.EuiFlexGroup, null,
                react_1.default.createElement(eui_1.EuiFlexItem, null,
                    react_1.default.createElement(eui_suggest_1.EuiSuggest, { status: status, value: inputValue, onKeyPress: this.onKeyPress, onItemClick: this.onItemClick.bind(this), append: searchFormatSelector, isPopoverOpen: isPopoverOpen, onClosePopover: this.closePopover.bind(this), onPopoverFocus: this.onPopoverFocus.bind(this), suggestions: suggestions, onInputChange: this.onInputChange, isInvalid: isInvalid, placeholder: placeholder })),
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(wz_search_buttons_1.WzSearchButtons, { options: buttonOptions || [], filters: filters, onChange: this.onButtonPress.bind(this) }))),
            react_1.default.createElement(eui_1.EuiFlexGroup, null,
                react_1.default.createElement(eui_1.EuiFlexItem, { grow: false },
                    react_1.default.createElement(wz_search_badges_1.WzSearchBadges, { filters: formatedFilter, onChange: this.onDeleteBadge.bind(this) })))));
    }
}
exports.default = WzSearchBar;
